from capturegame import CaptureGame
from gomoku import GomokuGame
from tasks.__init__ import *